"""This submodule contains several utility functions.

These functions are meant for internal usage.

"""
